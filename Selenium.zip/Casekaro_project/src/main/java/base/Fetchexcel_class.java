package base;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Fetchexcel_class {

	// Method to handle Excel file and extract data
	public static String[][] excelHandling(String path, String sheetName) throws IOException {
		// Open the Excel file
		FileInputStream fis = new FileInputStream(path);
		// Create workbook object using XSSFWorkbook for .xlsx files
		Workbook workbook = new XSSFWorkbook(fis);
		// Get the sheet by name
		Sheet sheet = workbook.getSheet(sheetName);
		// Get the number of rows in the sheet
		int rowCount = sheet.getPhysicalNumberOfRows(); // to get used row count
		// Get the first row to determine the number of columns
		Row row = sheet.getRow(0);
		// Get the number of cells in the first row to determine the number of columns
		int colCount = row.getPhysicalNumberOfCells(); // to get used cell count
		// Create a 2D array to store the data from the Excel sheet
		String[][] data = new String[rowCount][colCount];
		// Create a DataFormatter object to format cell values
		DataFormatter df = new DataFormatter();
		// Loop through each row and column to extract cell values
		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < colCount; j++) {
				// Format and store cell value in the data array
				data[i][j] = df.formatCellValue(sheet.getRow(i).getCell(j));
			}
		}
		// Loop through the data array and print each cell value
		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < colCount; j++) {
				System.out.println(data[i][j]);
			}
		}
		// Close the FileInputStream
		fis.close();
		// Return the data array
		return data;
	}
}
