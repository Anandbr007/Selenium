package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.Fileio_class;

public class Reusable_class {

	// WebDriver instance to control the browser
	private static WebDriver driver;

	// WebDriverWait instance for waiting for elements
	private WebDriverWait wait;

	// Properties instance to store configuration settings
	public static Properties prop;

	// String to store the browser choice
	public static String browser_choice;

	/**
	 * Constructor for Reusable_class.
	 */
	public Reusable_class(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		// Initialize properties from file
		prop = Fileio_class.getProperties();
	}

	/**
	 * Method to invoke the browser based on the configuration.
	 */
	public static WebDriver invokeBrowser() {
		if (prop == null) {
			// Initialize properties from file if not already initialized
			prop = Fileio_class.getProperties();
		}
		// Get browser choice from properties
		browser_choice = prop.getProperty("browserName");
		try {
			// Invoke Edge browser if specified
			if (browser_choice.equalsIgnoreCase("msedge")) {
				driver = Setupdriver_class.invokeEdgeBrowser();
			} else {
				// Throw exception for unsupported browsers
				throw new Exception("Invalid browser name provided in property file");
			}
		} catch (Exception e) {
			// Print stack trace if an exception occurs
			e.printStackTrace();
		}
		// Return the WebDriver instance
		return driver;
	}

	/**
	 * Method to open a browser and navigate to a specified website URL.
	 */
	public void openBrowser(String websiteUrlKey) {
		if (prop == null) {
			// Initialize properties from file if not already initialized
			prop = Fileio_class.getProperties();
		}
		try {
			// Open the specified website URL
			driver.get(prop.getProperty(websiteUrlKey));
		} catch (Exception e) {
			// Print stack trace if an exception occurs
			e.printStackTrace();
		}
	}

	// Method to click on a web element identified by locator with a specified
	// timeout
	public static void clickOn(By locator, Duration timeout) {
		try {
			// Wait until the element is clickable
			new WebDriverWait(driver, timeout).until(ExpectedConditions.elementToBeClickable(locator));
			// Click on the element
			driver.findElement(locator).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Method to send text to a web element with a specified timeout
	public static void sendText(WebElement element, String text) {
		try {
			// Wait until the element is visible
			new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOf(element));
			// Send text to the element
			element.sendKeys(text);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Method to get text from a web element identified by locator with a specified
	// timeout
	public static String getText(By locator) {
		String text = null;
		try {
			// Wait until the element is present
			new WebDriverWait(driver, Duration.ofSeconds(30))
					.until(ExpectedConditions.presenceOfElementLocated(locator));
			// Get text from the element
			text = driver.findElement(locator).getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	// Method to take a screenshot and save it to the specified file path
	public static void takeScreenShot(String filepath) {
		// Cast driver to TakesScreenshot interface
		TakesScreenshot takeScreenShot = (TakesScreenshot) driver;
		// Capture screenshot as File
		File srcFile = takeScreenShot.getScreenshotAs(OutputType.FILE);
		// Specify destination file
		File destFile = new File(filepath);
		try {
			// Copy the screenshot to the destination file
			FileUtils.copyFile(srcFile, destFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void delay(int n) {
		try {
			Thread.sleep(n*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
