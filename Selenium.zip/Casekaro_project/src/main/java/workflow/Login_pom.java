package workflow;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.Reusable_class;

public class Login_pom {


	private WebDriver driver;

	// Constructor to initialize WebDriver and PageFactory
	public Login_pom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	By loginicon=By.cssSelector("a[class='header__icon header__icon--account link focus-inset small-hide']");
	@FindBy(id = "CustomerEmail")
	WebElement emailtextbox;
	@FindBy(id = "CustomerPassword")
	WebElement passwordtextbox;
	By submitbtn=By.xpath("//form[@id='customer_login']/button");
	By txtmsg=By.className("customer__title");
	
	
	
	
	public void clickLoginbutton() {
		Reusable_class.clickOn(loginicon, Duration.ofSeconds(10));
	}
	
	public String validData(String email,String pass) {
		Reusable_class.delay(2);
		Reusable_class.sendText(emailtextbox, email);
		Reusable_class.sendText(passwordtextbox, pass);
		Reusable_class.delay(3);
		Reusable_class.clickOn(submitbtn, Duration.ofSeconds(10));
		String string= Reusable_class.getText(txtmsg);
		return string;
	}
}
