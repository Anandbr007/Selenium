package workflow;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import base.Reusable_class;

public class Search_pom {

	private WebDriver driver;

	// Constructor to initialize WebDriver and PageFactory
	public Search_pom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	By mobilecover=By.xpath("//ul[@class='list-menu list-menu--inline']/li[2]");
	By mobile=By.linkText("Apple");
	By model=By.xpath("(//div[@class='brand-name-main'])[1]");
	By mobilecase=By.linkText("Jai Shree Ram Hindu iPhone 15 Back Cover");
	
	public void mobileCovers() {
		Reusable_class.clickOn(mobilecover, Duration.ofSeconds(10));
	}
	
	public void companyname() {
		Reusable_class.clickOn(mobile, Duration.ofSeconds(10));
	}
	public void modelname() {
		Reusable_class.clickOn(model, Duration.ofSeconds(10));
	}
	public void mobilecase() {
		Reusable_class.clickOn(mobilecase, Duration.ofSeconds(10));
	}
}
