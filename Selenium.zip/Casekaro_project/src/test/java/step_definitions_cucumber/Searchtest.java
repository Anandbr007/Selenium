package step_definitions_cucumber;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import workflow.Search_pom;

public class Searchtest {

	private final WebDriver driver = Hooks.driver;
	public Search_pom search;

	@Given("User opens the website casekaro")
	public void user_opens_the_website_casekaro() {
		search = new Search_pom(driver);
		assertEquals(driver.getCurrentUrl(), "https://casekaro.com/");
	}

	@When("User clicks on Mobile covers")
	public void user_clicks_on_mobile_covers() {
		search = new Search_pom(driver);
		search.mobileCovers();

	}

	@Then("User validates the mobile covers page")
	public void user_validates_the_mobile_covers_page() {
		search = new Search_pom(driver);
		assertEquals(driver.getCurrentUrl(), "https://casekaro.com/pages/mobile-back-covers");
		assertEquals(driver.getTitle(), "Mobile Cover - Buy Mobile Phone Covers & Cases at Rs.99 – Casekaro");
	}

	@Then("User selects apple cover")
	public void user_selects_apple_cover() {
		search = new Search_pom(driver);
		search.companyname();
	}

	@Then("User validates the apple cover page")
	public void user_validates_the_apple_cover_page() {
		search = new Search_pom(driver);
		assertEquals(driver.getCurrentUrl(), "https://casekaro.com/pages/apple-covers-cases");
	}

	@Then("User selects iphone15")
	public void user_selects_iphone15() {
		search = new Search_pom(driver);
		search.modelname();
	}
	
	@Then("User validates the apple model page")
	public void user_validates_the_apple_model_page() {
		search = new Search_pom(driver);
		assertEquals(driver.getCurrentUrl(), "https://casekaro.com/collections/iphone-15-back-covers#MainContent");

	}

	@Then("User selects a case")
	public void user_selects_a_case() {
		search = new Search_pom(driver);
		search.mobilecase();
	}

	@Then("User validates the selected case page")
	public void user_validates_the_selected_case_page() {
		search = new Search_pom(driver);
		assertEquals(driver.getCurrentUrl(), "https://casekaro.com/products/jai-shree-ram-hindu-iphone-15-back-cover");
	}
}
