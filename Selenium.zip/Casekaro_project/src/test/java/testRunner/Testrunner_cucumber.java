package testRunner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

//Annotation to specify the options for Cucumber tests
@CucumberOptions(glue = { "classpath:step_definitions_cucumber" }, // Package where step definitions are located
		features = { "classpath:features/search.feature" }, // Location of feature files
		plugin = { "pretty", "html:target/site/cucumber-report.html" })

//Class to run Cucumber tests with TestNG
public class Testrunner_cucumber extends AbstractTestNGCucumberTests {
	// This class extends AbstractTestNGCucumberTests to run Cucumber tests with
	// TestNG
}
