package testcase;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.Fetchexcel_class;
import base.Reusable_class;
import workflow.Login_pom;



@Listeners(utilities.ExtentReportsListener.class)
public class Casekarotest {


		public WebDriver driver;
		public Reusable_class rf;
		public Login_pom login;

		// BeforeClass method to initialize reusable functions and browser invocation
		@BeforeTest(groups = "valid")
		public void before() {
			rf = new Reusable_class(driver);
			driver = Reusable_class.invokeBrowser();
		}

		// BeforeMethod method to open the test site before each test method
		@BeforeMethod(groups = "valid")
		public void getSite() {
			rf.openBrowser("testSiteURL");
		}
		
		@Test(priority = 1,groups = "valid")
		public void clickLogintest() {
			login = new Login_pom(driver);
			login.clickLoginbutton();
			assertEquals(driver.getCurrentUrl(), "https://casekaro.com/account/login");
		}
		
		@Test(priority = 2,dataProvider = "data" ,groups = "valid")
		public void validDatatest(String email,String pass) {
			login = new Login_pom(driver);
			login.clickLoginbutton();
			String str=login.validData(email, pass);
			assertEquals(str, "Account");
		}
		
		
		
		// DataProvider method to provide test data from an Excel file
		@DataProvider(name = "data")
		public String[][] getValiddata() throws IOException {
			String path = System.getProperty("user.dir") + "\\Testdata\\data.xlsx";
			String sheetName = "Sheet1";
			return Fetchexcel_class.excelHandling(path, sheetName);
		}
}
