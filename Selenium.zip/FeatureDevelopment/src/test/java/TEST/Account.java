package TEST;

public class Account {
	   
	private String number;
	private String name;
	public Account(String number, String name) {
		super();
		this.number = number;
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void deposit(String id,Double amount) {
		
	}
}
