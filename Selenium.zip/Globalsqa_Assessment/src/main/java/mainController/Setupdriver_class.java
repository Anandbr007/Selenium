package mainController;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class Setupdriver_class {

	private static WebDriver driver;

	// Method to invoke the Edge browser with custom options
	public static WebDriver invokeEdgeBrowser() {
		// Create EdgeOptions object to set browser options
		EdgeOptions options = new EdgeOptions();
		// Add arguments to customize browser behavior
		options.addArguments("--guest"); // Launch browser in guest mode
		options.addArguments("--start-maximized"); // Start the browser maximized
		// Initialize the EdgeDriver with the specified options
		driver = new EdgeDriver(options);
		// Return the WebDriver instance
		return driver;
	}
}
