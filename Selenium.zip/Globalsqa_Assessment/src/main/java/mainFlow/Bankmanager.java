 package mainFlow;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import mainController.Reusable_class;

public class Bankmanager {

	// WebDriver instance
	public static WebDriver driver;

	// Constructor to initialize WebDriver and PageFactory
	public Bankmanager(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Locators for various elements on the page
	By managerbtn = By.xpath("//button[@ng-click=\"manager()\"]");

	By addcustomer = By.xpath("//button[@ng-class='btnClass1']");

	@FindBy(xpath = "//input[@placeholder='First Name'][@ng-model='fName']")
	WebElement firstname;

	@FindBy(xpath = "//input[@placeholder='Last Name']")
	WebElement lastname;

	@FindBy(xpath = "//input[@placeholder='Post Code']")
	WebElement postcode;

	By addcustbtn = By.xpath("//button[@type='submit']");

	By openacc = By.xpath("//button[@ng-class='btnClass2']");

	By custnamedropdown = By.id("userSelect");

	By custname = By.cssSelector("option[value='6']");

	By currencydropdwn = By.id("currency");

	By rupeeselect = By.cssSelector("option[value='Rupee']");

	By submitbtn = By.xpath("//button[@type='submit']");

	By homebtn = By.cssSelector("button[ng-click='home()']");

	// Method to click on the login button
	public void clickLoginbutton() {
		Reusable_class.clickOn(managerbtn, Duration.ofSeconds(10));
	}

	// Method to add a new customer
	public void addCustomer() {
		Reusable_class.clickOn(addcustomer, Duration.ofSeconds(10));
	}

	// Method to enter customer details
	public void addcustomerDetails(String fname, String lname, String pin) {
		Reusable_class.sendText(firstname, fname);
		Reusable_class.sendText(lastname, lname);
		Reusable_class.sendText(postcode, pin);
		Reusable_class.clickOn(addcustbtn, Duration.ofSeconds(10));
		Alert a = driver.switchTo().alert();
		a.accept();
	}

	// Method to get customer name
	public String addcustomerName() {
		String name = "";
		Reusable_class.clickOn(openacc, Duration.ofSeconds(10));
		Reusable_class.clickOn(custnamedropdown, Duration.ofSeconds(10));
		name = Reusable_class.getText(custname);
		Reusable_class.clickOn(custname, Duration.ofSeconds(10));
		return name;
	}

	// Method to get customer currency
	public String addcustomerCurrency() {
		String currency = "";
		Reusable_class.clickOn(currencydropdwn, Duration.ofSeconds(10));
		currency = Reusable_class.getText(rupeeselect);
		Reusable_class.clickOn(rupeeselect, Duration.ofSeconds(10));
		return currency;
	}

	// Method to add account
	public void addingAccount() {
		Reusable_class.clickOn(submitbtn, Duration.ofSeconds(10));
		Alert a = driver.switchTo().alert();
		a.accept();
	}

	// Method to navigate back to home
	public void backToHome() {
		Reusable_class.clickOn(homebtn, Duration.ofSeconds(10));
	}
}
