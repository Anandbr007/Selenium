package mainFlow;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import mainController.Reusable_class;

public class Customerlogin {

	private WebDriver driver;

	// Constructor to initialize WebDriver and PageFactory
	public Customerlogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Locators for various elements on the page
	By loginbtn = By.cssSelector("button[class='btn btn-primary btn-lg'][ng-click='customer()']");

	By userselect = By.id("userSelect");

	By dropdownselect = By.cssSelector("option[value='2']");

	By clicksubmitbtn = By.xpath("//button[@type='submit']");

	By clickdepositbtn = By.cssSelector("button[ng-class='btnClass2']");

	@FindBy(css = "input[placeholder='amount']")
	WebElement amount_textarea;

	By clickdepositsubmit = By.cssSelector("button[type='submit']");

	By successmsg = By.xpath("//span[@ng-show='message']");

	// Method to click on the login button
	public void clickLoginbtn() {
		Reusable_class.clickOn(loginbtn, Duration.ofSeconds(10));
	}

	// Method to select customer from dropdown and submit
	public void nameSelect() {
		Reusable_class.clickOn(userselect, Duration.ofSeconds(10));
		Reusable_class.clickOn(dropdownselect, Duration.ofSeconds(10));
		Reusable_class.clickOn(clicksubmitbtn, Duration.ofSeconds(10));
	}

	// Method to deposit money
	public void depositMoney() {
		Reusable_class.clickOn(clickdepositbtn, Duration.ofSeconds(10));
		Reusable_class.sendText(amount_textarea, "10000");
		Reusable_class.clickOn(clickdepositsubmit, Duration.ofSeconds(10));
	}

	// Method to get success message after deposit
	public String successMsg() {
		return Reusable_class.getText(successmsg);
	}
}