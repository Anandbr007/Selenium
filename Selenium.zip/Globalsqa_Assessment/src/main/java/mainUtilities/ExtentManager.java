package mainUtilities;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {

	// ExtentReports and ExtentSparkReporter instances
	public static ExtentReports extent;
	public static ExtentSparkReporter htmlReporter;

	// Method to create an instance of ExtentReports
	public static ExtentReports createInstance() throws IOException {
		// Generate a unique report name with timestamp
		String repname = "TestReport-" + getTimeStamp() + ".html";
		// Define the HTML reporter and configure it
		htmlReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "//Reports//" + repname);
		htmlReporter
				.loadXMLConfig(System.getProperty("user.dir") + "\\src\\main\\java\\mainUtilities\\extent-config.xml");
		// Initialize ExtentReports and attach the HTML reporter
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		// Set system information for the report
		extent.setSystemInfo("OS", "Windows");
		extent.setSystemInfo("Host Name", "localhost");
		extent.setSystemInfo("Environment", "QA");
		extent.setSystemInfo("User Name", "Anand");
		return extent;
	}

	// Method to get a timestamp
	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}
}
