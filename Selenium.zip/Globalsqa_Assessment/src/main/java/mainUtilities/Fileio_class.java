package mainUtilities;

import java.io.FileInputStream;
import java.util.Properties;

public class Fileio_class {

	private static Properties prop;

	// Method to load properties from the configuration file
	public static Properties getProperties() {
		// Check if properties have already been loaded
		if (prop == null) {
			prop = new Properties();
			try {
				// Load properties from the configuration file
				FileInputStream fis = new FileInputStream(
						System.getProperty("user.dir") + "\\src\\test\\resources\\Objectrepository\\Config.properties");
				prop.load(fis);
			} catch (Exception e) {
				// Print stack trace if there's an exception while loading properties
				e.printStackTrace();
			}
		}
		// Return the loaded properties
		return prop;
	}
}