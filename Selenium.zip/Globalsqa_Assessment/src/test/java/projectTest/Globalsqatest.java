package projectTest;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import mainController.Fetchexcel_class;
import mainController.Reusable_class;
import mainFlow.Bankmanager;

@Listeners(mainUtilities.ExtentReportsListener.class)
public class Globalsqatest {

	public WebDriver driver;
	public Reusable_class rf;
	public Bankmanager manager;

	// BeforeClass method to initialize reusable functions and browser invocation
	@BeforeTest(groups = "valid")
	public void before() {
		rf = new Reusable_class(driver);
		driver = Reusable_class.invokeBrowser();
	}
	
	@AfterTest
	public void afterTest() {
        driver.quit();
    }

	// BeforeMethod method to open the test site before each test method
	@BeforeMethod(groups = "valid")
	public void getSite() {
		rf.openBrowser("testSiteURL");
	}

	// Test method to add a customer
	@Test(priority = 1, dataProvider = "data",groups = "valid")
	public void addCustomertest(String fname, String lname, String pin) {
		manager = new Bankmanager(driver);
		manager.clickLoginbutton();
		manager.addCustomer();
		manager.addcustomerDetails(fname, lname, pin);
	}

	// Test method to open an account
	@Test(priority = 2,groups = "valid")
	public void openingAccounttest() {
		manager = new Bankmanager(driver);
		manager.clickLoginbutton();
		String name = manager.addcustomerName();
		assertEquals(name, "anand br");
		String currency = manager.addcustomerCurrency();
		assertEquals(currency, "Rupee");
		manager.addingAccount();
		manager.backToHome();
		assertEquals(driver.getCurrentUrl(), "https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login");
	}

	// DataProvider method to provide test data from an Excel file
	@DataProvider(name = "data")
	public String[][] getValiddata() throws IOException {
		String path = System.getProperty("user.dir") + "\\TestData\\validData.xlsx";
		String sheetName = "Sheet1";
		return Fetchexcel_class.excelHandling(path, sheetName);
	}
}