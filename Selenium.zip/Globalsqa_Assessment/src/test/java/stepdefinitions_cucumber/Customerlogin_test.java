package stepdefinitions_cucumber;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import mainController.Reusable_class;
import mainFlow.Customerlogin;

public class Customerlogin_test {

	// WebDriver instance obtained from Hooks
	public WebDriver driver = Hooks.driver;
	Reusable_class rc;
	Customerlogin login;

	// Step definition for given step: User already opens the XYZ Bank site and goes
	// to login page
	@Given("User already open the website XYZ Bank site")
	public void user_already_open_the_website_xyz_bank_site() {
		// Initialize Customerlogin object and click on the login button
		login = new Customerlogin(driver);
		login.clickLoginbtn();
	}

	// Step definition for when step: User input customer name to login
	@When("User input already created customer name to login")
	public void user_input_already_created_customer_name_to_login() {
		// Initialize Customerlogin object and select customer name for login
		login = new Customerlogin(driver);
		login.nameSelect();
	}

	// Step definition for then step: User navigates to accounts page
	@Then("User goes to accounts page")
	public void user_goes_to_accounts_page() throws InterruptedException {
		// Wait for navigation and assert current URL
		Thread.sleep(1000);
		assertEquals(driver.getCurrentUrl(), "https://www.globalsqa.com/angularJs-protractor/BankingProject/#/account");
	}

	// Step definition for when step: User deposits money
	@When("User deposits money")
	public void user_deposits_money() {
		// Initialize Customerlogin object and perform deposit action
		login = new Customerlogin(driver);
		login.depositMoney();
	}

	// Step definition for then step: Check whether the money has been credited
	@Then("validate that the money has been credited")
	public void validate_that_the_money_has_been_credited() {
		// Initialize Customerlogin object and check for success message after deposit
		login = new Customerlogin(driver);
		String success = login.successMsg();
		assertEquals(success, "Deposit Successful");
	}
}