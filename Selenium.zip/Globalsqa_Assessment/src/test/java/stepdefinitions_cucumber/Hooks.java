package stepdefinitions_cucumber;

import java.util.Base64;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import mainController.Reusable_class;

public class Hooks {

	public static WebDriver driver; // WebDriver instance shared across test cases

	private ExtentReports extent; // ExtentReports instance for reporting
	private ExtentTest test; // ExtentTest instance for each test case

	@Before
	public void setup() {
		// Invoke the browser and open the test site before each scenario
		driver = Reusable_class.invokeBrowser();
		Reusable_class function = new Reusable_class(driver);
		function.openBrowser("testSiteURL");

		// Initialize Extent reports with the HTML reporter
		ExtentSparkReporter reporter = new ExtentSparkReporter("extent.html");
		extent = new ExtentReports();
		extent.attachReporter(reporter);

		// Create a new test in the Extent report
		test = extent.createTest("Project");
	}

	@After
	public void closeBrowser(Scenario scenario) {
		if (scenario.isFailed()) {
			// If scenario fails, take a screenshot and add it to the report
			final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			test.addScreenCaptureFromPath("data:image/png;base64," + Base64.getEncoder().encodeToString(screenshot));
		} else {
			// If scenario passes, take a screenshot and add it to the report, then mark
			// test as passed
			final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			test.addScreenCaptureFromPath("data:image/png;base64," + Base64.getEncoder().encodeToString(screenshot));
			test.pass("Test passed");
		}

		// Flush the Extent report to write the test results to the report
		extent.flush();

		// Quit the WebDriver instance
		driver.quit();
	}
}