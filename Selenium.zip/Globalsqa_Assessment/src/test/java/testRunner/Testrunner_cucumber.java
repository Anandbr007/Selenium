package testRunner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

//Annotation to specify the options for Cucumber tests
@CucumberOptions(glue = "stepdefinitions_cucumber", // Package where step definitions are located
		features = { "src/test/resources/features" } // Location of feature files
)

//Class to run Cucumber tests with TestNG
public class Testrunner_cucumber extends AbstractTestNGCucumberTests {
	// This class extends AbstractTestNGCucumberTests to run Cucumber tests with
	// TestNG
}