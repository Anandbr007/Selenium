package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utilities.FileIO;

public class ReusableFunction {
	
	private static WebDriver driver;
	private WebDriverWait wait;
	public static Properties prop;
	public static String browser_choice;
	
	public ReusableFunction(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		prop = FileIO.getProperties();
	}

	public static WebDriver invokeBrowser() {
		if(prop==null)
		{
			prop=FileIO.getProperties();
		}
		browser_choice = prop.getProperty("browserName");
		try {
			if (browser_choice.equalsIgnoreCase("msedge")) {
				driver = DriverSetup.invokeEdgeBrowser();
			} else if (browser_choice.equalsIgnoreCase("chrome")){
				driver = DriverSetup.invokeChromeBrowser();
			} else{
				throw new Exception("Invalid browser name provided in property file");
			}
		} catch (Exception e) {
		
		}
		return driver;
	}
	
	
	public void openBrowser(String websiteUrlKey) {
		if (prop == null) {
	        prop = FileIO.getProperties();
	    }
		try {
			driver.get(prop.getProperty(websiteUrlKey));

		} catch (Exception e) {
			e.printStackTrace();
		
		}
	}


	
	public static void sendText(WebElement element, String text) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOf(element));
//			driver.findElement(locator).sendKeys(text);
			element.sendKeys(text);
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}
	
	public static String getText(By locator) {
		String text = null;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.presenceOfElementLocated(locator));
			text = driver.findElement(locator).getText();
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return text;
	}
	
	public static void clickOn(By locator, Duration timeout) {
		try {
			new WebDriverWait(driver, timeout).until(ExpectedConditions
					.elementToBeClickable(locator));
			driver.findElement(locator).click();
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}
	
}


