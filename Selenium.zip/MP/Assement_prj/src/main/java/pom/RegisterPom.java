package pom;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunction;

public class RegisterPom {
	private WebDriver driver;
	ReusableFunction reusableFunction;
	
	public void RegisterPOM(WebDriver driver) {
		reusableFunction=new ReusableFunction(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	By regbtn=By.linkText("Register");
	
	@FindBy(xpath = "//input[@id='user_firstname'][@name='firstname']")
	WebElement fname;
	
	@FindBy(xpath = "//input[@id='user_surname'][@name='lastname']")
	WebElement lname;
	
	@FindBy(xpath = "//input[@id='user_phone'][@name='phone']")
	WebElement phno;
	
	By year=By.id("user_dateofbirth_1i");
	
	By yearValue=By.xpath("//option[@value='1948']");
	
	@FindBy(xpath = "//input[@id='user_address_attributes_street'][@name='street']")
	WebElement street;
	
	@FindBy(xpath = "//input[@id='user_address_attributes_city'][@name='city']")
	WebElement city;
	
	@FindBy(xpath = "//input[@id='user_address_attributes_county'][@name='county']")
	WebElement county;
	
	@FindBy(xpath = "//input[@id='user_address_attributes_postcode'][@name='post_code']")
	WebElement post_code;
	
	@FindBy(xpath = "//input[@id='user_user_detail_attributes_email'][@name='email']")
	WebElement email;
	
	@FindBy(xpath = "//input[@id='user_user_detail_attributes_password'][@name='password']")
	WebElement password;
	
	@FindBy(xpath = "//input[@id='user_user_detail_attributes_password_confirmation'][@name='c_password']")
	WebElement c_password;
	
	By clickBtn=By.xpath("//input[@name='submit'][@value='Create']");
	
	public void enterDetails(String fname2, String lname2, String phoneNumber, String street2, String city2, String country, String postcode, String email2, String pass, String cpass) throws InterruptedException {
		
		 ReusableFunction.clickOn(regbtn, Duration.ofSeconds(10));
		 Thread.sleep(1000);
		 ReusableFunction.sendText(fname,fname2);
		 ReusableFunction.sendText(fname,lname2);
		 ReusableFunction.sendText(fname,phoneNumber);
		 ReusableFunction.clickOn(year, Duration.ofSeconds(10));
		 ReusableFunction.clickOn(yearValue, Duration.ofSeconds(10));
		 ReusableFunction.sendText(street,street2);
		 ReusableFunction.sendText(city,city2);
		 ReusableFunction.sendText(county,country);
		 ReusableFunction.sendText(post_code,postcode);
		 ReusableFunction.sendText(email,email2);
		 ReusableFunction.sendText(password,pass);
		 ReusableFunction.sendText(c_password,cpass);
		 ReusableFunction.clickOn(clickBtn, Duration.ofSeconds(10));
	}
}

