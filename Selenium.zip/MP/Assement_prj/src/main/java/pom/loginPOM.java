package pom;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunction;



public class loginPOM {
	
	private WebDriver driver;
	
	public loginPOM(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath ="//input[@id='email'][@name='email']" )
	WebElement email;
	
	@FindBy(xpath ="//input[@id='password'][@name='password']" )
	WebElement Pass;
	
	
	 By loginbtn=By.xpath("//input[@name='submit'][@type='submit']");
	
	// Method to click on login icon
	public void login(String email1) {
		 ReusableFunction.sendText(email, email1);
	 }
	
	// Method to enter phone number for login
	public void Pass(String pass1) {
		ReusableFunction.sendText(Pass, pass1);
	}
	
	// Method to click on login button
	public void btnclick() {
		ReusableFunction.clickOn(loginbtn, Duration.ofSeconds(10));
	}
}
