package stepDefinition;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginTest {

	public WebDriver driver=Hooks.driver;
	
	@Given("User already open the website sauce demo")
	public void user_already_open_the_website_sauce_demo() {
	    assertEquals("https://demo.guru99.com/insurance/v1/index.php", driver.getCurrentUrl());
	}

	@When("User input {string} as username {string} as password")
	public void user_input_as_username_as_password(String string, String string2) {
		
	}

	@Then("User already on homepage")
	public void user_already_on_homepage() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("User get {string} as error message")
	public void user_get_as_error_message(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

}
