package pom;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunction;

public class LoginPOM {

private WebDriver driver;
	
	public LoginPOM(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	By loginicon=By.linkText("Log in");
	@FindBy(css = "input[type='email'][id='Email']")
	WebElement email;
	@FindBy(css = "input[type='password'][id='Password']")
	WebElement password;
	By registerbtn=By.cssSelector("button[type='submit'][class='button-1 login-button']");
	
	public void clickloginicon() {
		ReusableFunction.clickOn(loginicon, Duration.ofSeconds(10));
	}
	public void sendemail(String email1) {
		ReusableFunction.sendText(email, email1);
	}
	public void sendpass(String pass) {
		ReusableFunction.sendText(password, pass);
	}
	public void loginbtn() {
		ReusableFunction.clickOn(registerbtn, Duration.ofSeconds(10));
	}

}
