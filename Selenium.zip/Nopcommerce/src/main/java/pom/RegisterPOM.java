package pom;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunction;

public class RegisterPOM {

private WebDriver driver;
	
	public RegisterPOM(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	By regicon=By.linkText("Register");
	By genderRadio=By.cssSelector("input[type='radio'][id='gender-male']");
	@FindBy(css = "input[type='text'][id='FirstName']")
	WebElement firstname;
	@FindBy(css = "input[type='text'][id='LastName']")
	WebElement lastname;
	@FindBy(css = "input[type='email'][id='Email']")
	WebElement email;
	@FindBy(css = "input[type='password'][id='Password']")
	WebElement password;
	@FindBy(css = "input[type='password'][id='ConfirmPassword']")
	WebElement cpassword;
	By registerbtn=By.cssSelector("button[type='submit'][id='register-button']");
	
	public void clickregIcon() {
		ReusableFunction.clickOn(regicon, Duration.ofSeconds(10));
	}
	public void sendDetails(String fname,String lname,String email1,String pass,String cpass) {
		ReusableFunction.clickOn(genderRadio, Duration.ofSeconds(10));
		ReusableFunction.sendText(firstname, fname);
		ReusableFunction.sendText(lastname, lname);
		ReusableFunction.sendText(email, email1);
		ReusableFunction.sendText(password, pass);
		ReusableFunction.sendText(cpassword, cpass);
	
	}
	public void clickregbtn() {
		ReusableFunction.clickOn(registerbtn,  Duration.ofSeconds(10));
	}
}
