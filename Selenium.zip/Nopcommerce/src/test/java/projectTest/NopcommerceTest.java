package projectTest;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.ExcelHandling;
import base.ReusableFunction;
import pom.RegisterPOM;
import utilities.ExtentReportsListener;


@Listeners(utilities.ExtentReportsListener.class)
public class NopcommerceTest implements ITestListener{

	ExtentReportsListener extentReportsListener = new ExtentReportsListener();
	public WebDriver driver;
	public ReusableFunction reusableFunctions;
	public RegisterPOM register;
	
	@BeforeClass
	public void before() {
		// Initialize reusable functions and browser invocation before the test class
		reusableFunctions=new ReusableFunction(driver);
		driver = ReusableFunction.invokeBrowser();
	}
	
	@BeforeMethod
	public void getsite() {
		// Open the test site before each test method
		reusableFunctions.openBrowser("testSiteURL");
	}
	@Test(priority = 1)
	public void testinvalidRegister() {
		register=new RegisterPOM(driver);
		register.clickregIcon();
		register.clickregbtn();
		driver.navigate().back();
	}
	
	@Test(dataProvider = "validRegister",priority = 2)
	public void testValidregister(String fname,String lname,String email1,String pass,String cpass) {
		register=new RegisterPOM(driver);
		register.clickregIcon();
		register.sendDetails(fname,lname,email1,pass,cpass);
		register.clickregbtn();
		assertEquals("https://demo.nopcommerce.com/registerresult/1?returnUrl=/", driver.getCurrentUrl());
	}
	
	
	
	@DataProvider(name="validRegister")
	public String[][] getRegisterdata() throws IOException{
		String path=System.getProperty("user.dir")+"\\TestData\\Registerdetails.xlsx";
		String sheetName="Sheet1";
		return ExcelHandling.excelHandling(path,sheetName);
	}
	
	
}
