package stepDefinition;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.LoginPOM;

public class LoginTest {
	
	private WebDriver driver=Hooks.driver;
	
	@Given("User already open the website nopcommerce")
	public void user_already_open_the_website_nopcommerce() {
		assertEquals("https://demo.nopcommerce.com/", driver.getCurrentUrl());
	}

	@When("User input {string} as username {string} as password")
	public void user_input_as_username_as_password(String uname, String pass) {
		LoginPOM login=new LoginPOM(driver);
		login.clickloginicon();
		login.sendemail(uname);
		login.sendpass(pass);
		login.loginbtn();
	}

	@Then("User already on homepage")
	public void user_already_on_homepage() {
		assertEquals("https://demo.nopcommerce.com/",driver.getCurrentUrl());

	}

	@Then("User get {string} as error message")
	public void user_get_as_error_message(String string) {
		assertEquals("https://demo.nopcommerce.com/login?returnUrl=%2F", driver.getCurrentUrl());
	}

}
