package Project;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.xpath.XPath;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ReusableFunction;

public class CheckoutPage {

public WebDriver driver;
WebDriverWait wbDriverWait;
ReusableFunction rf=new ReusableFunction(driver);
    
    public CheckoutPage(WebDriver driver) {
    	this.driver=driver;
    	PageFactory.initElements(driver, this);
    }
    
	@FindBy(className  = "product_sort_container")
	WebElement filterElement;
	
	@FindBy(xpath = "//option[@value='za']")
	WebElement ztoa;
	
	@FindBy(id = "item_3_title_link")
	WebElement productname1;
	@FindBy(id = "item_2_title_link")
	WebElement productname2;
	@FindBy(id = "item_5_title_link")
	WebElement productname3;
	@FindBy(id = "item_1_title_link")
	WebElement productname4;
	@FindBy(id = "item_0_title_link")
	WebElement productname5;
	@FindBy(id = "item_4_title_link")
	WebElement productname6;
	
	@FindBy(id = "add-to-cart-test.allthethings()-t-shirt-(red)")
	WebElement addtocart;
	@FindBy(id = "add-to-cart-sauce-labs-onesie")
	WebElement addtocart1;
	@FindBy(className = "shopping_cart_badge")
	WebElement validcart;
	@FindBy(id = "remove-sauce-labs-onesie")
	WebElement removecart;
	@FindBy(className = "shopping_cart_link")
	WebElement carticon;
//	@FindBy(id = "checkout")
	@FindBy(xpath = "//*[@id='checkout']")
	WebElement checkout;
	
	public void clickFilter() {
		filterElement.click();
			
	}
	public void ZtoA() {
		ztoa.click();
	}
	public List<String> getProductList() {
		String arr1=productname1.getText();
		String arr2=productname2.getText();
		String arr3=productname3.getText();
		String arr4=productname4.getText();
		String arr5=productname5.getText();
		String arr6=productname6.getText();
		
		List<String> inputList=new ArrayList<String>();
		inputList.add(arr1);
		inputList.add(arr2);
		inputList.add(arr3);
		inputList.add(arr4);
		inputList.add(arr5);
		inputList.add(arr6);
		
		return inputList;
	}
	public boolean isSortedDescending(List<String> list) {
		List<String> finalList=new ArrayList<String>();
		finalList.addAll(list);
		Collections.sort(finalList,Collections.reverseOrder());
		if(list.equals(finalList)) {
			return true;
		}
		return false;
	}
	
	public void addtocartclick() {
//		addtocart.click();
		rf.clickOnElement(addtocart);
	}
	public void addtocartclick1() {
//		addtocart1.click();
		rf.clickOnElement(addtocart1);
	}
	public void Carticon() {
		rf.clickOnElement(carticon);
	}
	public String ValidCart() {
		return validcart.getText();
	}
	public void Removecart() {
		rf.clickOnElement(removecart);
	}
	
	public void Checkout() {
		rf.clickOnElement(checkout);
	}
}
