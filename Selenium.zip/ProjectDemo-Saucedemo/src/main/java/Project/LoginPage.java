package Project;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.ReusableFunction;


public class LoginPage {
public WebDriver driver;
    
    public LoginPage(WebDriver driver) {
    	this.driver=driver;
    	PageFactory.initElements(driver, this);
    }
    
    @FindBy(id="user-name")
    WebElement username;
    
    @FindBy(id="password")
    WebElement password;
    
    @FindBy(id="login-button")
    WebElement loginbutton;
    
    @FindBy(xpath="//h3[@data-test='error']")
    WebElement invalid;
    
    public void enterUsername(String uname) {
    	username.sendKeys(uname);  	
    }
    public void enterPassword(String pword) {
    	password.sendKeys(pword);  	
    }
    public void clickLogin() {
    	loginbutton.click();
    }
    public String invaliddata() {
    	String s= invalid.getText();
    	return s;
    }
	
	
//	public WebDriver driver;
//	
//	
//	public SauceDemo(WebDriver driver) {
//		this.driver = driver;
//		PageFactory.initElements(driver, this);
//	}
//	
//	
//	@FindBy(id="user-name")
//	WebElement uname;
//	@FindBy(id="password")
//	WebElement upassword;
//	@FindBy(id="login-button")
//	WebElement loginButton;
//	
//
//	
//	public void login(String username,String password){
//	
////		ReusableFunction.setTexttoInputField(uname, username);
////		ReusableFunction.setTexttoInputField(upassword, password);
////		ReusableFunction.clickOnElement(loginButton);
//		uname.sendKeys(username);
//		upassword.sendKeys(password);
//		loginButton.click();
//	}
		
	
}
