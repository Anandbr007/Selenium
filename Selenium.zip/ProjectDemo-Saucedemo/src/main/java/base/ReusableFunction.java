package base;

import java.io.File;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utilities.FileIO;


public class ReusableFunction {

	public static WebDriver driver;
	private static WebDriverWait wait;
	private static Properties properties;
	private static String browser_choice;
	
	public ReusableFunction(WebDriver driver) {
		this.driver=driver;
		wait=new WebDriverWait(driver, Duration.ofSeconds(10));
		properties=FileIO.getProperties();
	}
	
	public  WebDriver invokeBrowser() {
		if (properties== null) {
			properties=FileIO.getProperties();
		}
		try {
			browser_choice=properties.getProperty("browser");
			if (browser_choice.equalsIgnoreCase("chrome")) {
				driver=DriverSetup.invokeChromeBrowser();
			}else if(browser_choice.equalsIgnoreCase("edge")) {
				driver=DriverSetup.invokeEdgeBrowser();
			}else {
				throw new Exception("Invalid browser name provided in property file");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return driver;
	}
	/**********open website*********/
	public void openWebsite() {	
		try {
			driver.get(properties.getProperty("url"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**********wait for the element to display on the page*********/
	public static void waitforElementtoDisplay(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	/**********set text to any input field*********/
	public static void setTexttoInputField(WebElement element,String input) {
		waitforElementtoDisplay(element);
		element.clear();
		element.sendKeys(input);
	}
	/**********Click Element*********/
	public void clickOnElement(WebElement element) {
		element.click();
	}
	
	/*********Report fail Test**********/
	public void reportFail(String message) {
		Assert.fail("Testcase Failed: "+message);
	}
}
