package utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class FileIO {

	private static Properties properties;
	
	public static Properties getProperties() {
		if(properties==null){
			properties=new Properties();
			FileInputStream fs;
			try {
				fs = new FileInputStream("C:\\Users\\268852\\eclipse-workspace\\ProjectDemo-Saucedemo\\src\\test\\resources\\ObjectRepository\\configuration.properties");
				properties.load(fs);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		return properties;
	}
}
