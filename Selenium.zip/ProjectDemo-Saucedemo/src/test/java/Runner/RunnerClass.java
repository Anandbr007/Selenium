package Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions( 
		glue = "step_definitions.login_page",
		features="C:\\Users\\268852\\eclipse-workspace\\ProjectDemo-Saucedemo\\src\\test\\resources\\features\\Login.feature",
		plugin = {
				"pretty",
						"com.aventstack.extentreports.cucumber.adapter.ExtentCucmberAdapter:",
						"timeline:test-output-thread/"}
		)

public class RunnerClass extends AbstractTestNGCucumberTests{

}
