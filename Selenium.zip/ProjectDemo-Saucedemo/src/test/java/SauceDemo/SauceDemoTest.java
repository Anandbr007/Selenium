package SauceDemo;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.List;

import org.checkerframework.checker.units.qual.s;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Project.CheckoutPage;
import Project.ExcelsheetHandling;
import Project.LoginPage;
import base.ReusableFunction;
import dev.failsafe.internal.util.Assert;

public class SauceDemoTest {
	
public WebDriver driver;
CheckoutPage cp;



    @BeforeClass
    public void beforeClass() {
    	ReusableFunction fn = new ReusableFunction(driver);
    	driver=fn.invokeBrowser();	
    
    }
    
    @BeforeMethod
    public void before() {
    	ReusableFunction fn = new ReusableFunction(driver);
    	fn.openWebsite();
    }
    
    @DataProvider(name="validdata")
    public String[][] getData() throws IOException{
	String path =  "\\Testdata\\TestData.xlsx";
	String sheetName1="Sheet1";
	return ExcelsheetHandling.getExcelData(path,sheetName1);
}
   @DataProvider(name="invaliddata")
    public String[][] getvalidData() throws IOException{
	String path ="\\Testdata\\WrongTestData.xlsx";
	String sheetName2="Sheet1";
	return ExcelsheetHandling.getExcelData(path,sheetName2);
}
 
    @Test(priority=1,dataProvider="invaliddata")
    public void testInvalidLogin(String username, String password) {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername(username);
    	login.enterPassword(password);
    	login.clickLogin();
  	    assertEquals(login.invaliddata(),"Epic sadface: Username and password do not match any user in this service");
  	    assertEquals("Swag Labs",driver.getTitle());
    }
    
  
    @Test(priority=2)
    public void testNullLogin() {
    	LoginPage login= new LoginPage(driver);
    	login.clickLogin();
    	assertEquals(login.invaliddata(),"Epic sadface: Username is required");
   	    assertEquals("Swag Labs",driver.getTitle());
    }
    @Test(priority=3)
    public void testOneInputLogin() {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername("username");
    	login.clickLogin();
    	assertEquals(login.invaliddata(),"Epic sadface: Password is required");
    }
    
    @Test(priority=4,dataProvider="validdata")  
    public void testValidLogin(String username,String password) {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername(username);
    	login.enterPassword(password);
    	login.clickLogin();
    	assertEquals("https://www.saucedemo.com/inventory.html",driver.getCurrentUrl());
	    assertEquals("Swag Labs",driver.getTitle());
    }
    
    @Test(priority=5)
    public void testClickFilter() throws InterruptedException {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername("standard_user");
    	login.enterPassword("secret_sauce");
    	login.clickLogin();
    	
    	CheckoutPage checkout=new CheckoutPage(driver);
    	checkout.clickFilter();
    	checkout.ZtoA();
    	List<String> productList = checkout.getProductList();
        boolean sorted = checkout.isSortedDescending(productList);
        assertTrue(sorted);
    }
    
    @Test(priority=6)
    public void testButtonclick() throws InterruptedException {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername("standard_user");
    	login.enterPassword("secret_sauce");
    	login.clickLogin();
    	
    	CheckoutPage checkout=new CheckoutPage(driver);
    	checkout.addtocartclick();
    	checkout.addtocartclick1();
        checkout.Carticon();
    	String s=checkout.ValidCart();
    	assertTrue(s.equals("2"));
    }
    
    
    @Test(priority=7)
    public void removeButtonClick() {
		LoginPage login=new LoginPage(driver);
		login.enterUsername("standard_user");
    	login.enterPassword("secret_sauce");
    	CheckoutPage checkout=new CheckoutPage(driver);
    	login.clickLogin();
    	checkout.Carticon();
    	
    	checkout.Removecart();
    	String s=checkout.ValidCart();
    	assertTrue(s.equals("1"));
	}
    @Test(priority=8)
    public void Testcheckout() {
    	LoginPage login=new LoginPage(driver);
		login.enterUsername("standard_user");
    	login.enterPassword("secret_sauce");
    	login.clickLogin();
    	CheckoutPage checkout=new CheckoutPage(driver);
    	checkout.Carticon();
    	checkout.Checkout();
    	assertEquals("https://www.saucedemo.com/checkout-step-one.html",driver.getCurrentUrl());
    }
    
    
    
}
//	public WebDriver driver;
//	
//	@BeforeClass
//	public void browserSetup() {
//		ReusableFunction reusable=new ReusableFunction(driver);
//		driver=reusable.invokeBrowser();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//	}
//	
//	@BeforeMethod
//	public void before() {
//		ReusableFunction reusable=new ReusableFunction(driver);
//		reusable.openWebsite();
//	}
//	
////	@Test(priority = 1,dataProvider = "testdata")
////	public void LoginwithIncorrectInput() {
////		
////	}
//	
//	@Test(priority = 1,dataProvider = "testdata")
//	public void LoginwithCorrectInput(String username,String password) throws IOException, InterruptedException{
//		SauceDemo sd = new SauceDemo(driver);
//		sd.login(username,password);
//		String currentURL="https://www.saucedemo.com/";
//		String getURL=driver.getCurrentUrl();
//		assertEquals(currentURL,getURL);
//	}
//	
////	@AfterMethod
////	public void closing()
////	{
////		driver.close();
////	}
//	
//	@DataProvider
//	public static String[][] testdata() throws IOException{
//		
//		String[][] logindata=ExcelsheetHandling.getExcelData("\\TestData\\TestData.xlsx", "Sheet1");
//		//String[][]logindata= {{"mnjdhd","djhdj"}};
//		return logindata;
//		
//	}

