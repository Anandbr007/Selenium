package step_definitions.login_page;

import static org.testng.Assert.assertEquals;

import java.awt.peer.LabelPeer;

import org.openqa.selenium.WebDriver;

import Project.LoginPage;
import base.ReusableFunction;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginwithValidData {
	public WebDriver driver;
	LoginPage lp;
	@Given("User already open the website sauce demo")
	public void verifyLoginPage() {
		ReusableFunction fn = new ReusableFunction(driver);
    	driver=fn.invokeBrowser();	
    	lp=new LoginPage(driver);
    	fn.openWebsite();
	}
	
	@When("User input {string} as username {string} as password")
	public void inputCredential(String username,String password) {
		lp.enterUsername(username);
		lp.enterPassword(password);
		lp.clickLogin();
	}
	
	@Then("User already on homepage")
	public void user_already_on_homepage() {
		assertEquals("https://www.saucedemo.com/inventory.html",driver.getCurrentUrl());
	}
	
	@Then("User get {string} as error message")
	public void user_get_as_error_message(String string) {
		assertEquals("https://www.saucedemo.com/", driver.getCurrentUrl());
		}

	
}
