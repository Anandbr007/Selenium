package SauceDemo;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SauceDemoTest {
	
public static WebDriver driver;
	
	@BeforeMethod
	public void setUp() {
		EdgeOptions options = new EdgeOptions();
		options.addArguments("guest");
		options.addArguments("--start-maximized");
		options.addArguments("headless");
		driver = new EdgeDriver(options);
		driver.get("https://www.saucedemo.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		PageFactory.initElements(driver, this);
	}
	@FindBy(id="user-name")
	WebElement uname;
	@FindBy(id="password")
	WebElement upassword;
	@FindBy(id="login-button")
	WebElement loginButton;
	@FindBy(xpath="//div[@class='error-message-container error']")
	WebElement errormessage;
		@Test(dataProvider = "getLoginData",groups="valid")
		public void testLogin(String username,String password) throws InterruptedException {
			String[][] logindata = null;
			try {
				logindata = getLoginData();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			System.out.println(logindata.length);
			Thread.sleep(1000);
			uname.sendKeys(username);
			upassword.sendKeys(password);
			loginButton.click();
			String currentURL=	"https://www.saucedemo.com/inventory.html";
			String getURL=driver.getCurrentUrl();
			assertEquals(currentURL,getURL);
			
		
		
			
	}
		@Test(dataProvider = "getLoginData1")
		public void testLoginforWrongInput(String username,String password) throws InterruptedException {
			String[][] logindata = null;
			try {
				logindata = getLoginData1();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			System.out.println(logindata.length);
			Thread.sleep(1000);
			uname.sendKeys(username);
			upassword.sendKeys(password);
			loginButton.click();
			Thread.sleep(1000);
			assertEquals(errormessage.getText(),"Epic sadface: Sorry, this user has been locked out.");
			String currentURL=driver.getCurrentUrl();
			String URl="https://www.saucedemo.com/";
			assertEquals(currentURL,URl);
			
		
		
	}
		@Test(groups="invalid")
		public void testNullValues() throws InterruptedException {
			loginButton.click();
			Thread.sleep(1000);
			assertEquals(errormessage.getText(),"Epic sadface: Username is required");
			assertTrue(errormessage.isDisplayed());
		}
		
	
	@DataProvider
	public static String[][] getLoginData() throws IOException{
		String[][] logindata =ExcelHandling.getExcelData("C:\\Users\\268852\\eclipse-workspace\\SauceDemo\\TestData\\datasheet.xlsx","Sheet1");
		return logindata;
		
	}
	@DataProvider
	public static String[][] getLoginData1() throws IOException{
		String[][] logindata = ExcelHandling.getExcelData("C:\\Users\\268852\\eclipse-workspace\\SauceDemo\\TestData\\wrongdatasheet.xlsx","Sheet1");
		return logindata;
		
	}
	@AfterMethod
	public void closing()
	{
		driver.close();
	}
	
}

