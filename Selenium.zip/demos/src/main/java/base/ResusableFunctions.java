package base;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utilities.FileIO;

public class ResusableFunctions {

	private static WebDriver driver;
	private WebDriverWait wait;
	public static Properties properties;
	public static String browser_choice;
	public ResusableFunctions(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		properties = FileIO.getProperties();
	}
	/*********Report fail Test**********/
	public static void reportFail(String message) {
		Assert.fail("Testcase Failed: "+message);
	}
	public static WebDriver invokeBrowser() {
		if(properties==null) {
			properties=FileIO.getProperties();
		}
		browser_choice = properties.getProperty("browser");
		try {
			if (browser_choice.equalsIgnoreCase("chrome")) {
				driver = DriverSetup.invokeChromeBrowser();
			} else if (browser_choice.equalsIgnoreCase("edge")) {
				driver = DriverSetup.invokeEdgeBrowser();
			}else {
				throw new Exception("Invalid browser name provided in property file");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return driver;
	}
	
	/**********open website*********/
	public void openWebsite(String url) {
		try {
			driver.get(properties.getProperty(url));
		}catch(Exception e) {
			reportFail(e.getMessage());
		}
	}
	
	/**********wait for the element to display on the page*********/
	public void waitForElementToDisplay(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	/**********set text to any input field*********/
	public void setTextToInputField(WebElement element, String text) {
		waitForElementToDisplay(element);
	    element.clear();
	    element.sendKeys(text);
	}

	public void clickOnElement(WebElement element) {
		element.click();
	}
}

