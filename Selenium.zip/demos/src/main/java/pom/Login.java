package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ResusableFunctions;

public class Login {
	WebDriver driver;
	ResusableFunctions resuseableFunctions;
	
	public Login(WebDriver driver) {
		this.driver=driver;
		this.resuseableFunctions=new ResusableFunctions(driver);
		PageFactory.initElements(driver, this);
		
	}
	//webelement username=driver.findElement(by.id("user"));
	@FindBy(id = "user")
	private WebElement username;
	
	@FindBy(id = "pass")
	private WebElement password;
	
	@FindBy(id = "btnLogin")
	private WebElement Login;

	public void enterUsername(String uname) {
		resuseableFunctions.setTextToInputField(username, uname);
	}
	public void enterPassword(String pwd) {
		resuseableFunctions.setTextToInputField(password, pwd);
	}
	public void clickLogin() {
		resuseableFunctions.clickOnElement(Login);
	}
}
