package Excelhandling2D;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.DriverSetup;

public class DataProviderdemo {

	public WebDriver driver;
	

	@BeforeMethod
	public void before() {
//		ChromeOptions options = new ChromeOptions();
//		options.addArguments("--disable-notifications");
//		options.addArguments("--start-maximized");
//		driver=new ChromeDriver(options);
		driver=DriverSetup.invokeEdgeBrowser();
	
		driver.get("https://www.mycontactform.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	@DataProvider(name = "testdata")
	public String[][] getData() throws IOException{
		String path =System.getProperty(("user.dir")+"\\Testdata\\datasheet.xlsx");
		String sheetname="datasheet";
		return UsernameNdPassword.getExcelData(path,sheetname);
		
	}

	@Test(dataProvider="testdata")
	public void dataProvider(String username,String password) {
		driver.findElement(By.xpath("(//input[@class='txt_log'])[1]")).sendKeys(username);
		driver.findElement(By.xpath("(//input[@class='txt_log'])[2]")).sendKeys(password);
	}
}
