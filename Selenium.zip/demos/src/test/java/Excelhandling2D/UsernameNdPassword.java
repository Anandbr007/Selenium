package Excelhandling2D;

import java.io.FileInputStream;
import java.io.IOException;


import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UsernameNdPassword {

	public static String[][] getExcelData(String path,String sheetname) throws IOException {
//		try {
			FileInputStream fs=new FileInputStream(System.getProperty("user.dir")+"\\Testdata\\datasheet.xlsx");
			
			
			Workbook wb=new XSSFWorkbook(fs);
			Sheet sheet=wb.getSheet(sheetname);
			
			
			int rowcount=sheet.getPhysicalNumberOfRows();
			Row row = sheet.getRow(0);
			
	
			int colcount=row.getPhysicalNumberOfCells();
			String arr[][]=new String[rowcount][colcount];
			
//			for (int i = 0; i < rowcount; i++) {
//				Row rows = sheet.getRow(i);
//				for (int j = 0; j < colcount; j++) {
//					arr[i][j]=rows.getCell(j).getStringCellValue();
//				}
//				
//			}
//			
//			for (int i = 0; i < rowcount; i++) {
//				for (int j = 0; j < colcount; j++) {
//					System.out.print(arr[i][j]+'\t');
//				}
//				System.out.println();
//			}
		
//			return arr;
			DataFormatter dFormatter=new DataFormatter();
			for (int i = 0; i <rowcount; i++) {
				for (int j = 0; j < colcount; j++) {
					arr[i][j]=dFormatter.formatCellValue(sheet.getRow(i).getCell(j));
					System.out.println(arr[i][j]);
				}
			}
			return arr;
			
//			
//		} catch (Exception e) {
//			System.out.println(e);
//		}
		
		
	} 
	

}
