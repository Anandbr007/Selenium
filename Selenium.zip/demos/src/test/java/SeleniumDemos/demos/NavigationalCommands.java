package SeleniumDemos.demos;


import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class NavigationalCommands {

	public static WebDriver driver;
	@Test
	public void navigationalCommands() {
		driver=Sample.Sample1();
		//to open an url
		driver.get("https://www.google.com/");
		//another way
		driver.navigate().to("https://www.amazon.com/");//it will store cookie
		//back
		driver.navigate().back();
		//forward
		driver.navigate().forward();
		//refresh
		driver.navigate().refresh();
	}
}
