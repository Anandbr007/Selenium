package SeleniumDemos.demos;

import java.awt.Window;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

public class Sample {

	@Test
	public static WebDriver Sample1() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");
		
		//open browser using chromedriver by upcasting webdriver
		WebDriver driver=new ChromeDriver(options);
		
		driver.manage().window().maximize();
		return driver;
}
}