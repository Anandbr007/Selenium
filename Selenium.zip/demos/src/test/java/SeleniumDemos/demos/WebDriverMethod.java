package SeleniumDemos.demos;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class WebDriverMethod {

	public static WebDriver driver;
	
	@Test
	public void WebDriverMethods() {
		driver=Sample.Sample1();
		//to open an url
		driver.get("https://www.google.com/");
		//to print the title of the page
		String title=driver.getTitle();
		System.out.println(title);
		//to print the current url
		String url=driver.getCurrentUrl();
		System.out.println(url);
		
		driver.close();
		driver.quit();
		
		
	}
}
