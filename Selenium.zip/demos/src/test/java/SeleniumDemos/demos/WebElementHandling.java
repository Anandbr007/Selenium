package SeleniumDemos.demos;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.bidi.Input;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class WebElementHandling {

	public static WebDriver driver;
	
	@Test
	public void webelementhandling() throws InterruptedException, IOException {
		driver=Sample.Sample1();
		driver.get("https://www.mycontactform.com/");
		WebElement sampleformslink=driver.findElement(By.linkText("Sample Forms"));
		sampleformslink.click();
		//or
//		driver.findElement(By.linkText("sample forms")).click();
		driver.findElement(By.id("subject")).sendKeys("Roshan m shafeek");
		driver.findElement(By.id("email")).sendKeys("Roshan@99.com");
		driver.findElement(By.name("q1")).sendKeys("Rainbow is roshans favorite");
//		driver.findElement(By.name("submit")).sendKeys(Keys.ENTER);
		driver.findElement(By.cssSelector("input[name='email_to[]'][value='1']")).click();
//		driver.findElement(By.cssSelector("input[id='q4'][value='Second Option']")).click();
		
		driver.findElement(By.xpath("//textarea[@id='q2']")).sendKeys("hlo im anand b r,hufrufneufn");
	
		
		WebElement drops=driver.findElement(By.id("q3"));
		Select s=new Select(drops);
		s.selectByVisibleText("Third Option");
		
		driver.findElement(By.cssSelector("input[name='q4'][id='q4']")).click();
		driver.findElement(By.cssSelector("input[name='q5'][id='q5']")).click();
		driver.findElement(By.xpath("//input[@name='checkbox6[]'][@value='Fourth Check Box']")).click();
		driver.findElement(By.cssSelector("input[name='q7'][id='q7']")).sendKeys("06-11-2002");
		driver.findElement(By.cssSelector("input[name='q7'][id='q7']")).sendKeys(Keys.ESCAPE);
//		Thread.sleep(2000);
//		driver.findElement(By.cssSelector("input[name='attach4589'][id='attach4589'][type='file']")).sendKeys("‪C:\\Users\\268852\\Downloads\\USECASE.txt");
//		driver.close();
		List<WebElement> links=driver.findElements(By.tagName("a"));
		System.out.println(links.size());
		
		List<WebElement> links1=driver.findElements(By.xpath("//input[@type='checkbox']"));
		System.out.println(links1.size());
		
		for(int i=0;i<links1.size();i++) {
			links1.get(i).click();
			
		}
		
		//FOR CLICLING EVERY LINKS
		int count=0;
		List<WebElement> links2=driver.findElements(By.xpath("//div[@id='left_col_top']/ul/li/a"));
		System.out.println(links2.size());
		for (int i = 1; i <= links2.size(); i++) {
			List<WebElement> links3=driver.findElements(By.xpath("//div[@id='left_col_top']/ul["+i+"]/li/a"));
			for (int i1 = 1	; i1 <= links3.size(); i1++) {
				count++;
				driver.findElement(By.xpath("//div[@id='left_col_top']/ul["+i+"]/li["+i1+"]/a")).click();
				File srcFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			    FileUtils.copyFile(srcFile, new File(System.getProperty("user.dir")+"/screenshots/"+"ss"+count+".jpg"));
		}
			
		
			
		
		
		//driver.close();
}}
}