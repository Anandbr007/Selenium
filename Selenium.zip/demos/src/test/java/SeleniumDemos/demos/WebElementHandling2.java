package SeleniumDemos.demos;

import java.util.List;

import javax.tools.ForwardingFileObject;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.bidi.Input;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class WebElementHandling2 {

	public static WebDriver driver;
	
	@Test
	public void webelementhandling() throws InterruptedException {
		driver=Sample.Sample1();
		driver.get("https://www.mycontactform.com/");
		WebElement sampleformslink=driver.findElement(By.linkText("Sample Forms"));
		sampleformslink.click();

		List<WebElement> links2=driver.findElements(By.xpath("//div[@id='left_col_top']/ul/li/a"));
		System.out.println(links2.size());
		for (int i = 1; i < links2.size(); i++) {
			List<WebElement> links3=driver.findElements(By.xpath("//div[@id='left_col_top']/ul["+i+"]/li/a"));
			for (int i1 = 1	; i1 < links3.size(); i1++) {
				driver.findElement(By.xpath("//div[@id='left_col_top']/ul["+i+"]/li["+i1+"]/a")).click();

		}
		//driver.close();
}
}}