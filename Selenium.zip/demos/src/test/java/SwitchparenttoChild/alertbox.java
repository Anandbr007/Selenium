package SwitchparenttoChild;

import java.awt.Desktop.Action;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import SeleniumDemos.demos.Sample;

public class alertbox {

	public static WebDriver driver;
@Test
	public void alert() {
		driver=Sample.Sample1();
		driver.get("https://demo.automationtesting.in/Windows.html");
		WebElement sourcElement=driver.findElement(By.className("dropdown-toggle"));
		
		Actions a=new Actions(driver);
		a.moveToElement(sourcElement).perform();
		
		driver.findElement(By.linkText("Alerts")).click();
		//clicking normal alertbox
//		driver.findElement(By.cssSelector("button[class='btn btn-danger']")).click();
		
		driver.findElement(By.linkText("Alert with OK & Cancel")).click();
		driver.findElement(By.cssSelector("button[class='btn btn-primary']")).click();
		
		//controlling alert box
		Alert alert =driver.switchTo().alert();
//		alert.accept();
//		alert.dismiss();
//		alert.sendKeys("");
//		alert.getText();
	}
}
