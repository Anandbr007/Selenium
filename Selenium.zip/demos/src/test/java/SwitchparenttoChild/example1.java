package SwitchparenttoChild;

import java.sql.Driver;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import SeleniumDemos.demos.Sample;

public class example1 {
	

		public static WebDriver driver;
		
		@Test
		public void Switch(){
		driver=Sample.Sample1();
		driver.get("https://demo.automationtesting.in/Windows.html");
		
		WebElement sampleformslink=driver.findElement(By.linkText("Open New Seperate Windows"));
		sampleformslink.click();
		
		driver.findElement(By.cssSelector("button[class='btn btn-primary']")).click();
		
		//to get parent window
		String parent=driver.getWindowHandle();
		
		//obtain all window handles
		Set<String> handles=driver.getWindowHandles();
		
		System.out.println("total windows opened:"+handles.size());
		
		for(String handle:handles) {
			if(!handle.equals(parent)) {
				driver.switchTo().window(handle);
				System.out.println("child window title:"+driver.getTitle());
				//click downloads
				driver.findElement(By.linkText("Downloads")).click();
				//close the child window
				driver.close();
			}
			//switch back to the parent window
			driver.switchTo().window(parent);
			System.out.println("parent window title:"+driver.getTitle());
		}
}
		
		
}
