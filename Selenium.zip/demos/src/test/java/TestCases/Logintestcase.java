package TestCases;

import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import base.ResusableFunctions;

public class Logintestcase {

	private WebDriver driver;
	private ResusableFunctions resusablefunctions;
	@BeforeClass
	public void beforeTest() {
		driver=resusablefunctions.invokeBrowser();
		resusablefunctions=new ResusableFunctions(driver);
	}
	@Test
	public void openTestSite() {
		  // Use the method to navigate to a URL
        resusablefunctions.openWebsite("testSiteURL");
        //use assertions

	}
}
