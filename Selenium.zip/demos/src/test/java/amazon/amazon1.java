package amazon;


import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import SeleniumDemos.demos.Sample;

public class amazon1 {

	public static WebDriver driver;
	@Test
	public void mousehoverClick() throws InterruptedException{
		driver=Sample.Sample1();
		driver.get("https://www.amazon.in/");
		WebElement sourcElement=driver.findElement(By.id("nav-link-accountList-nav-line-1"));
//		WebElement sourcElement1=driver.findElement(By.id("nav-icon nav-arrow "));
	
		
		Actions a=new Actions(driver);
		a.moveToElement(sourcElement).perform();
		
		WebElement sampleformslink=driver.findElement(By.linkText("Your Recommendations"));
		sampleformslink.click();
		
		List<WebElement> links3=new ArrayList<WebElement>();
		
		for (int i = 0; i < 5; i++) {
			if (i==4) {
				Thread.sleep(2000);
			}
			links3.addAll(driver.findElements(By.xpath("//*[@id=\"p13n-asin-index-"+i+"\"]/div/div[2]/div/span/div")));
			
		}
		
		System.out.println(links3.size());
		for (int i = 0; i < 5; i++) {
			
			System.out.println(links3.get(i).getText());
			
		}
		
		String urlString="https://www.amazon.in/gp/yourstore?ref_=nav_AccountFlyout_recs";
		
		
		assertEquals(urlString, driver.getCurrentUrl());
	}
}
