package assignment;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AngularPOM {
	WebDriver driver;
	WebDriverWait wait;

	public void AngularPOM(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}
	
	@FindBy(linkText="My Courses")
	WebElement mycourse;
	
	public void mycourse() {
		mycourse.click();
	}
	
	@FindBy(className="total-lessons")
	WebElement beginnercoursElement;
	
	public void beginnercourse() {
		beginnercoursElement.click();
	}
	
	@FindBy(className="viewed")
	WebElement helicopterviewElement;
	
	public void helicopter() {
		helicopterviewElement.click();
	}
	
	@FindBy(xpath = "//table[@class='card lessons-list table']/tbody/tr[1]/td/lesson-viewed-checkbox/checkbox/div[1]")
	WebElement checkboxElement;
	
	public void checkbox() {
		checkboxElement.click();
	}
	
	

}
