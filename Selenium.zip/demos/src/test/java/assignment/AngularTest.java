package assignment;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AngularTest {

	public  WebDriver driver;
	AngularPOM obj=new AngularPOM();
	
	@BeforeTest
	public void setup() {
		driver=Browserconfig.setup();
		driver.get("https://angular-university.io/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	@Test
	public void angular() {
		
		obj.AngularPOM(driver);
		obj.mycourse();
		obj.beginnercourse();
		obj.helicopter();
		obj.checkbox();
		
	}
}
