package assignment;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import SeleniumDemos.demos.Sample;



public class Assignment1 {
	

	public static WebDriver driver;
	@Test
	public void assignment1(){
		driver=Sample.Sample1();
		driver.get("https://www.ebay.com/");
		driver.findElement(By.cssSelector("input[type='text'][class='gh-tb ui-autocomplete-input'][name='_nkw']")).sendKeys("selenium");
		driver.findElement(By.id("gh-btn")).click();
		
		driver.findElement(By.linkText("Buy It Now")).click();
		
		driver.findElement(By.cssSelector("button[class='fake-menu-button__button btn btn--small btn--secondary'][aria-label='Sort selector. Best Match selected.']")).click();
		driver.findElement(By.linkText("Time: newly listed")).click();
		String strin = driver.findElement(By.cssSelector(".s-item__dynamic.s-item__listingDate:nth-child(1)")).getText();
		System.out.println(strin);
		String[] mon=strin.split("-");
		if(mon[0]=="sep")
			System.out.println("it is september");
		else {
			System.out.println("it is not september");
		}
				
		
	}
}
