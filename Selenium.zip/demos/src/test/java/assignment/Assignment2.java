package assignment;

import static org.testng.Assert.assertEquals;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import SeleniumDemos.demos.Sample;

public class Assignment2 {

	public static WebDriver driver;
	@Test
	public void assignment2() throws InterruptedException{
		driver=Sample.Sample1();
		driver.get("https://www.amazon.in/");
		
		driver.findElement(By.linkText("Today's Deals")).click();
		driver.findElement(By.linkText("Clearance")).click();
		driver.findElement(By.linkText("Watches")).click();
		driver.findElement(By.xpath("(//*[@class='a-icon a-icon-checkbox'])[1]")).click();
		Thread.sleep(2000);
		String string=driver.findElement(By.cssSelector("span[class='a-size-medium-plus a-color-base a-text-bold']")).getText();

		
		assertEquals(string, "Results");
		
		String string1=driver.findElement(By.linkText("French Connnection Analog Dial Women's Watch")).getText();
		String[] str=string1.split(" ");

		
		assertEquals(str[5], "Watch");
		}
				
		
	}

