package assignment;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Assignment2ElementTest {
	WebDriver driver;
	WebDriverWait wait;

	public void AmazonPOM(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}

	@FindBy(linkText = "Today's Deals")
	WebElement todayD;

	public void todayDeals() {
		todayD.click();
	}
	
	@FindBy(linkText="Clearance")
	WebElement clearance;
	
	public void clearance() {
		clearance.click();
	}
	
	@FindBy(linkText="Watches")
	WebElement watches;
	
	public void watch() {
		watches.click();
	}
	
	@FindBy(xpath="(//*[@class='a-icon a-icon-checkbox'])[1]")
	WebElement checkbox;

	public void checkbox() {
		checkbox.click();
	}
	
	@FindBy(css="span[class='a-size-medium-plus a-color-base a-text-bold']")
	WebElement textElement;
	
	public String textcompare() {
		String string=textElement.getText();
		return string;
		
	}
	
	@FindBy(linkText="French Connnection Analog Dial Women's Watch")
	WebElement watchcompare;
	
	public String watchcompare() {
		String string=watchcompare.getText().toLowerCase();
		return string;
		
	}
}
