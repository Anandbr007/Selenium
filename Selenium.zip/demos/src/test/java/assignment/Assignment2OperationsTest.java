package assignment;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Assignment2OperationsTest {

	public WebDriver driver;
	Assignment2ElementTest obj=new Assignment2ElementTest();
	
	@BeforeTest
	public void setup() {
		driver=Browserconfig.setup();
		driver.get("https://www.amazon.in/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	@Test
	public void test() {
		obj.AmazonPOM(driver);
		obj.todayDeals();
		obj.clearance();
		obj.watch();
		obj.checkbox();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		String string=obj.textcompare();
		assertEquals(string, "Results");
		String string2=obj.watchcompare();
		assertTrue(string2.contains("watch"));
		
		
	}
}
