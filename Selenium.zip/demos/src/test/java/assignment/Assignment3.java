package assignment;
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import SeleniumDemos.demos.Sample;

public class Assignment3 {

	public static WebDriver driver;
	@Test
	public void assignment3(){
		driver=Sample.Sample1();
		driver.get("https://www.myntra.com");
		
		driver.findElement(By.className("desktop-searchBar")).sendKeys("Bluetooth headphones");
		driver.findElement(By.className("desktop-submit")).click();
		
		WebElement element=driver.findElement(By.className("sort-sortBy"));
		Actions action=new Actions(driver);
		action.moveToElement(element).perform();
		
		driver.findElement(By.xpath("//*[@id=\"desktopSearchResults\"]/div[1]/section/div[1]/div[1]/div/div/div/ul/li[2]")).click();
		
		driver.findElement(By.cssSelector("ul[class='brand-list'] li label[class='vertical-filters-label common-customCheckbox'] div[class='common-checkboxIndicator']")).click();
//		driver.findElement(By.className("common-checkboxIndicator")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	String str=driver.findElement(By.xpath("(//h3[@class='product-brand'])[1]")).getText();
	assertEquals(str, "JBL");
	}
}