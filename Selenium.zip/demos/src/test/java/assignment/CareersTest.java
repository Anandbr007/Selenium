package assignment;

import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.time.Duration;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.DriverSetup;

public class CareersTest {
	public WebDriver driver;
	CareerTestpom obj=new CareerTestpom();
	
	@BeforeTest
	public void setup() {
		driver=DriverSetup.invokeEdgeBrowser();
		driver.get("https://www.ust.com/en/careers");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	@Test
	public void test() throws InterruptedException {
		obj.CareerPOM(driver);
		obj.button();
		obj.career();
		obj.writetoTextbox();
		obj.tvm();
		obj.experience();
		obj.Button();
		boolean res=obj.validate();
		assertTrue(res);
		
	}

}
class CareerTestpom{
	WebDriver driver;
	WebDriverWait wait;

	public void CareerPOM(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}
	
	
	
	@FindBy(id= "onetrust-accept-btn-handler")
	WebElement cookie;
	
	@FindBy(linkText = "India Careers")
	WebElement careerElement;
	
	@FindBy(xpath = "//input[@class='form-control input-lg search_textbox']")
	WebElement textboxElement;
	
	@FindBy(xpath = "//span[@class='multiselect-selected-text location-select-text location-icon-before']")
	WebElement dropdownElement;
	
	@FindBy(xpath = "//input[@class='multiselect-search']")
	WebElement tvmElement;
	
	@FindBy(css = "label>input[value='Thiruvananthapuram']")
	WebElement checkboxElement;
	
	@FindBy(xpath =" //div[@class='input-group experience-div']")
	WebElement experiencedropbox;
	
	@FindBy(xpath = "//input[@value='4']")
	WebElement experiencevalue;
	
	@FindBy(xpath = "//button[@class='btn btn-primary-search pull-right btn-search btn-1-color-theme tooltips js-jobs-filter']")
	WebElement button;
	
	public void button() throws InterruptedException {
//		wait.until(ExpectedConditions.visibilityOf(cookie));
		Thread.sleep(2000);
		cookie.click();
	}
	
	public void career() {
		careerElement.click();
	}
	
	public void writetoTextbox() {
		String parent=driver.getWindowHandle();
		Set<String> handles=driver.getWindowHandles();
		
		for(String handle:handles) {
			if(!handle.equals(parent)) {
				driver.switchTo().window(handle);
				textboxElement.sendKeys("test automation",Keys.ENTER);
				
			
			}
		}
	}
	
	
	public void tvm() throws InterruptedException {
		Thread.sleep(3000);
		dropdownElement.click();
		checkboxElement.click();
	}
	
	public void experience() {
		experiencedropbox.click();
		experiencevalue.click();
	}
	
	public void Button() {
		button.click();
	}
	public boolean validate() throws InterruptedException {
		Thread.sleep(2000);
		String string=	driver.getCurrentUrl();
		if(string.contains("search=test%20automation")&&string.contains("location=Thiruvananthapuram")&&string.contains("exp=4")) {
			return true;
		}
		return false;
	}
	
	@AfterMethod
	public void captureScreenshotOfFail(ITestResult result) {
		if(result.getStatus() == ITestResult.FAILURE) {
			try {
				File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				Date d1 = new Date();
				FileUtils.copyFile(screenshot, new File(System.getProperty("user.dir")+"/screenshots/"+ d1.getTime()+ "ss.jpg"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
		
	}

