package assignment;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.DriverSetup;

public class FeedbackTest {

	public WebDriver driver;
	FeedbackTestpom obj=new FeedbackTestpom();
	
	@BeforeTest
	public void setup() {
		driver=DriverSetup.invokeEdgeBrowser();
		driver.get("https://www.jenkins.io");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	@Test
	public void test() throws InterruptedException {
		obj.FeedbackPOM(driver);
		obj.documents();
		obj.guidedtour();
		obj.pagehelpful();
		obj.radiobutton();
		obj.captcha();
		obj.submit();
	}
}

class FeedbackTestpom{
	WebDriver driver;
	WebDriverWait wait;

	public void FeedbackPOM(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}
	@FindBy(xpath = "//a[@class='btn btn-secondary m-1']")
	WebElement documentation;
	
	@FindBy(xpath = "//div[@class='sidebar-nav tour'][@id='sidebar-content']/ul[2]/li[1]/a")
	WebElement guidedtour;
	
	@FindBy(linkText = "Was this page helpful?")
	WebElement pghelpful;
	
	@FindBy(xpath = "//form[@id='ss-form']/p/input[@id='h1'][@value='Yes']")
	WebElement radiobtn;
	
	@FindBy(xpath = "//label[@id='ssTestLabel']")
	WebElement captcha;
	
	@FindBy(xpath = "//input[@name='ssTestValue']")
	WebElement textboxElement; 
	
	@FindBy(xpath = "//input[@class='button'][@type='submit'][@value='Submit']")
	WebElement submitbtn;
	
	public void documents() {

		documentation.click();
	}
	public void guidedtour(){
		
		guidedtour.click();
	}
	
	public void pagehelpful() {
		pghelpful.click();
	}
	public void radiobutton() {
		radiobtn.click();
	}
	
	public void captcha() {
		String string=captcha.getText();
		String[] str=string.split(" ");
		int a=Integer.parseInt(str[4]);
		int b=Integer.parseInt(str[6]);
		int total=a+b;
		String result=Integer.toString(total);
		textboxElement.sendKeys(result);
	}
	
	public void submit() {
		submitbtn.click();
	}
}
