package assignment;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Excelhandling2D.UsernameNdPassword;
public class SauceDemoTest {
	
public static WebDriver driver;
	
	@BeforeMethod
	public void setUp() {
		EdgeOptions options = new EdgeOptions();
		options.addArguments("guest");
		options.addArguments("--start-maximized");
//		options.addArguments("headless");
		driver = new EdgeDriver(options);
		driver.get("https://www.saucedemo.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		PageFactory.initElements(driver, this);
	}
	@FindBy(id="user-name")
	WebElement uname;
	@FindBy(id="password")
	WebElement upassword;
	@FindBy(id="login-button")
	WebElement loginButton;
	@FindBy(xpath="//div[@class='error-message-container error']")
	WebElement errormessage;
		@Test(dataProvider = "getLoginData",groups="valid")
		public void testLogin(String username,String password) throws InterruptedException {
			Object[][] logindata = null;
			try {
				logindata = getLoginData();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			System.out.println(logindata.length);
			Thread.sleep(100);
			uname.sendKeys(username);
			upassword.sendKeys(password);
			loginButton.click();
			String currentURL=	"https://www.saucedemo.com/inventory.html";
			String getURL=driver.getCurrentUrl();
			assertEquals(currentURL,getURL);
			
		
		
	}
		@Test(dataProvider = "getLoginData1",groups="invalid")
		public void testLoginforWrongInput(String username,String password) throws InterruptedException {
			Object[][] logindata = null;
			try {
				logindata = getLoginData();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			System.out.println(logindata.length);
			Thread.sleep(100);
			uname.sendKeys(username);
			upassword.sendKeys(password);
			loginButton.click();
			Thread.sleep(100);
			assertEquals(errormessage.getText(),"Epic sadface: Sorry, this user has been locked out.");
			String currentURL=driver.getCurrentUrl();
			String URl="https://www.saucedemo.com/";
			assertEquals(currentURL,URl);
			
		
		
	}
		@Test(groups="invalid")
		public void testNullValues() throws InterruptedException {
			loginButton.click();
			Thread.sleep(100);
			assertEquals(errormessage.getText(),"Epic sadface: Username is required");
//			assertTrue(errormessage.isDisplayed());
		}
		
	
	@DataProvider
	public static Object[][] getLoginData() throws IOException{
		Object[][] logindata =UsernameNdPassword.getExcelData("C:\\Users\\268859\\Desktop\\SeleniumAssignments\\UST-Selenium\\TestData\\Unameandpass.xlsx","Sheet1");
		return logindata;
		
	}
	@DataProvider
	public static Object[][] getLoginData1() throws IOException{
		Object[][] logindata = UsernameNdPassword.getExcelData("C:\\Users\\268859\\Desktop\\SeleniumAssignments\\UST-Selenium\\TestData\\wronguandpass.xlsx","Sheet1");
		return logindata;
		
	}
	@AfterMethod
	public void closing()
	{
		driver.close();
	}
	
}
