package assignment;

import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.DriverSetup;

public class asds {

		public WebDriver driver;
		CareerTestpomhh obj=new CareerTestpomhh();
		
		@BeforeTest
		public void setup() {
			driver=DriverSetup.invokeEdgeBrowser();
			driver.get("https://www.saucedemo.com/inventory.html");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		}
		@Test
		public void test() throws InterruptedException {
			obj.CareerPOM(driver);
			obj.enterUsername("standard_user");
			obj.enterPassword("secret_sauce");
			obj.clickLogin();
			obj.clickFilter();
			obj.ZtoA();
			obj.getProductList();
			
		}

	}


	class CareerTestpomhh{
		WebDriver driver;
		WebDriverWait wait;

		public void CareerPOM(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
			wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		}
		
		 @FindBy(id="user-name")
		    WebElement username;
		    
		    @FindBy(id="password")
		    WebElement password;
		    
		    @FindBy(id="login-button")
		    WebElement loginbutton;
		    
		    @FindBy(xpath="//h3[@data-test='error']")
		    WebElement invalid;
		    
		
		@FindBy(className = "product_sort_container")
		WebElement filterElement;
		
		@FindBy(xpath = "//option[@value='za']")
		WebElement ztoa;
		
		@FindBy(id = "item_3_title_link")
		WebElement productname1;
		@FindBy(id = "item_2_title_link")
		WebElement productname2;
		@FindBy(id = "item_5_title_link")
		WebElement productname3;
		@FindBy(id = "item_1_title_link")
		WebElement productname4;
		@FindBy(id = "item_0_title_link")
		WebElement productname5;
		@FindBy(id = "item_4_title_link")
		WebElement productname6;
		
		public void enterUsername(String uname) {
	    	username.sendKeys(uname);  	
	    }
	    public void enterPassword(String pword) {
	    	password.sendKeys(pword);  	
	    }
	    public void clickLogin() {
	    	loginbutton.click(); 	
	    }
	    public String invaliddata() {
	    	String s= invalid.getText();
	    	return s;
	    }
		
		public void clickFilter() {
			filterElement.click();
		}
		public void ZtoA() {
			ztoa.click();
		}
		public void getProductList() {
			String arr1=productname1.getText();
			String arr2=productname2.getText();
			String arr3=productname3.getText();
			String arr4=productname4.getText();
			String arr5=productname5.getText();
			String arr6=productname6.getText();
			
			List<String> inputList=new ArrayList<String>();
			inputList.add(arr1);
			inputList.add(arr2);
			inputList.add(arr3);
			inputList.add(arr4);
			inputList.add(arr5);
			inputList.add(arr6);
			System.out.println(inputList);
			verifySortOrder(inputList);
		}
		public void verifySortOrder(List<String> list) {
			List<String> finalList=new ArrayList<String>();
			finalList.addAll(list);
			Collections.sort(finalList,Collections.reverseOrder());
			
		}
		


}
