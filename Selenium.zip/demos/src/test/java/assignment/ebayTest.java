package assignment;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ebayTest {
	public WebDriver driver;


	@BeforeTest
	public void setup() {
		driver=Browserconfig.setup();
		driver.get("https://www.ebay.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	@Test
	public void relative() {
		By ebaysearch = RelativeLocator.with(By.tagName("input")).toLeftOf(By.xpath("//*[@id='gh-cat']"));
		driver.findElement(ebaysearch).sendKeys("samsung");

		driver.findElement(By.xpath("//*[@id='gh-btn']")).click();
	}
}
