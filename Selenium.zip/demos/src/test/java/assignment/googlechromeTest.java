package assignment;

import java.awt.TextArea;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.bidi.Input;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class googlechromeTest {

	public WebDriver driver;
	
	
	@BeforeTest
	public void setup() {
		driver=Browserconfig.setup();
		driver.get("https://www.google.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	@Test
	public void relative() {
		By searchLocator = RelativeLocator.with(By.xpath("//textarea")).toLeftOf(By.xpath("//div[@class='XDyW0e']"));
		driver.findElement(searchLocator).sendKeys("selenium",Keys.ENTER);
	}
}
