package dateautomation;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import SeleniumDemos.demos.Sample;

public class ixigo {

	public static WebDriver driver;
	@Test
		public void click() throws InterruptedException {
		System.out.println("enter");
		Scanner scanner=new Scanner(System.in);
		String inputString=scanner.nextLine();
		
			driver=Sample.Sample1();
			driver.get("https://www.ixigo.com/");
		driver.findElement(By.xpath("/html/body/main/div[2]/div[1]/div[3]/div[2]/div[2]/div[1]/div/div/div/div/p[2]")).click();
		Thread.sleep(2000);
		String string= driver.findElement(By.xpath("/html/body/main/div[2]/div[1]/div[3]/div[2]/div[2]/div[3]/div/div[1]/div[1]/button[2]/span[1]")).getText();
			String[] str=string.split(" ");
			String month=str[0];

			while(!inputString.equals(month)) {
				driver.findElement(By.xpath("/html/body/main/div[2]/div[1]/div[3]/div[2]/div[2]/div[3]/div/div[1]/div[1]/button[3]")).click();
				
				string= driver.findElement(By.xpath("/html/body/main/div[2]/div[1]/div[3]/div[2]/div[2]/div[3]/div/div[1]/div[1]/button[2]/span[1]")).getText();
				 str=string.split(" ");
				month=str[0];

				
			}
			
	}

		
		
	
	
}
