package example1;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import SeleniumDemos.demos.Sample;

public class MouseAction {

	public static WebDriver driver;
	@Test
	public void mouseaction() {
		
		driver=Sample.Sample1();
		driver.get("https://jqueryui.com/");
		WebElement sampleformslink=driver.findElement(By.linkText("Droppable"));
		sampleformslink.click();
		WebElement frame=driver.findElement(By.className("demo-frame"));
		driver.switchTo().frame(frame);
		WebElement source=driver.findElement(By.id("draggable"));
		WebElement destination=driver.findElement(By.id("droppable"));
		
		//actions
		Actions a=new Actions(driver);
		a.clickAndHold(source)
		.moveToElement(destination)
		.release(destination)
		.build()
		.perform();
	} 

}
