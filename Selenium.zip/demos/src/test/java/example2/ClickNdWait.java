package example2;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import SeleniumDemos.demos.Sample;
import SwitchparenttoChild.alertbox;

public class ClickNdWait {

	public static WebDriver driver;
	@Test
	public void clickandwait() {
		driver=Sample.Sample1();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://chercher.tech/practice/explicit-wait-sample-selenium-webdriver");
		
		WebElement webelementsname=	driver.findElement(By.id("alert"));
		webelementsname.click();
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfAllElements(webelementsname));
		
		Alert alert =driver.switchTo().alert();
		alert.accept();
		
//		//javascript executor
//		JavascriptExecutor js=(JavascriptExecutor) driver;
//		js.executeScript("window.scrollBy(0,1000)"); //1000 pixel
//		
//		//scroll to element
//		WebElement element=driver.findElement(By.xpath("//a[@href='/my/orders']"));
//		js.executeScript("arguments[0].scrollIntoView();", element);
		
//		//click
//		js.executeScript("arguments[0].click();", element);
		
//		//to enter text
//		js.executeScript("arguments[0].value='Roshan M shafeek';", element);
	}
}
