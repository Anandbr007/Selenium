package excelpackage;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelHandling {

	@Test
	public void excelHandling() {
		//file input stream
		try {
			FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + "\\Testdata\\testdata.xlsx");
			
			//apache poi - handles excel files
			//xlsx - XSSFworkbook
			//xls - HSSworkbook --> poi library
			Workbook workbook = new XSSFWorkbook(fileInputStream);
			Sheet sheet = workbook.getSheet("sheet1");
			
			int rowCount = sheet.getPhysicalNumberOfRows();
			
			
			//int colCount = row.getPhysicalNumberOfCells();
			
			System.out.println("Total number of rows used :" + rowCount);
			//System.out.println("Total number of columns used :" + colCount);
			for (int i = 0; i < rowCount; i++) {
				Row row = sheet.getRow(i);
				String data = row.getCell(0).getStringCellValue();
				System.out.println(data);
			}
		
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	
	}
	
	

