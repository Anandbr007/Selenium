package SeleniumDemos.demos;
 
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
 
public class Config {
	/**
	 * @return 
	 * @return 
	 * @return 
	 * @return
	 */
	static Properties prop;
	public static void loadprop(String fpath) {
		try {
			FileInputStream fis=null;
            fis=new FileInputStream(fpath);
            prop=new Properties();
            prop.load(fis);
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	public static WebDriver webChromeconfig() {
		loadprop("C:\\Users\\268852\\eclipse-workspace\\demos\\src\\test\\resources\\ObjectRepository\\configuration.properties");
		String driverPath=prop.getProperty("driverPath");
		System.setProperty("webdriver.chrome.driver",driverPath);
		ChromeOptions options=new ChromeOptions();
		options.addArguments(prop.getProperty("disableNoti"));
		WebDriver driver=new ChromeDriver(options);
		return driver;
	}
	public static WebDriver webEdgeconfig() {
		loadprop("C:\\Users\\268852\\eclipse-workspace\\demos\\src\\test\\resources\\ObjectRepository\\configuration.properties");
		EdgeOptions options=new EdgeOptions();
//		options.addArguments("--disabled-notifications--");
		options.addArguments(prop.getProperty("disableNoti"));
		WebDriver driver = new 	EdgeDriver(options);
		return driver;
	}
//	public static void main(String args[]) {
//		webEdgeconfig();
//		webChromeconfig();
//	}
 
}