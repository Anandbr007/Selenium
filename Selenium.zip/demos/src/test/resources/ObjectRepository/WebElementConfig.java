package SeleniumDemos.demos;

 
import java.util.Properties;
import java.util.concurrent.TimeUnit;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
 
public class WebElementConfig {
	static WebDriver driver=Config.webChromeconfig();
	public static void main(String args[]) {
		driver.get("https://www.saucedemo.com/");
		Config.loadprop("C:\\Users\\268852\\eclipse-workspace\\demos\\src\\test\\resources\\ObjectRepository\\WebElementConfig.java");
		WebElement uname=webelements(driver,"uname");
		uname.sendKeys("standard_user");
		WebElement upass=webelements(driver,"upass");
		upass.sendKeys("secret_sauce");
		WebElement logButton=webelements(driver,"logButton");
		logButton.click();
 
	
	}
	private static WebElement webelements(WebDriver driver,String propertyKey) {
		// TODO Auto-generated method stub
		    String locator=Config.prop.getProperty(propertyKey);
	        String[]locators=locator.split(" ");
	        String ltype=locators[0];
	        String lval=locators[1];
 
            switch(ltype) {
            case "id":System.out.println(driver.findElement(By.id(lval)));
            	return driver.findElement(By.id(lval));
            case "name":System.out.println(driver.findElement(By.name(lval)));
            	return driver.findElement(By.name(lval));
            case "xpath":System.out.println(driver.findElement(By.xpath(lval)));
            	return driver.findElement(By.xpath(lval));
            }
            return null;
       }
 
 
	
 
 
}
